process.env["NTBA_FIX_319"] = 1;

// Twitter API
// var Twit = require('twit');
// var config = require('./config');
// var T = new Twit(config);

//Telegram API
const TelegramBot = require('node-telegram-bot-api');
const token = '503344691:AAHJBp-rMUMJurHmacHyZs-o1uwSaxwnD_Y';
const bot = new TelegramBot(token, {polling: true});

// Kucoin API
const Kucoin = require('kucoin-api');
let kc = new Kucoin(
    '5a5554642f29eb6a595cd2db',
    '96feb741-be52-4e1d-99cb-e973635365ae'
)

// let coinsAvailable = [];
// kc.getCoins().then(
// (result) => {
// result.data.forEach(element => {
//     coinsAvailable.push(element);
// });
// })
// .catch(console.error);

// @crypto_rand
// var cryptoRand = T.stream('statuses/filter', {follow: '859484337850523648'});

// cryptoRand.on('tweet', function(err, data){
//     coins.forEach(element => {
//         if(data.text.contains(element)){
                     
//             // Send actual tweet
//             bot.sendMessage('', data.text);
//             bot.getMe().then(
//                 (result) => {
//                     console.log(result);
//                 }
//             )
//         }
//     })
    
// });
const chatId;

bot.onText(/\/start/, (msg, match) =>{
    chatId = msg.chat.id;
})

bot.getMe().then(
    (result) => {
        //console.log(result);
    bot.sendMessage(result.id, 'Let \'s see if this shit actually works.')
    }
).catch(console.error)


function getTickerInfo_BTC(currency){
    if(currency != 'BTC'){
        kc.getTicker({pair: 'BTC' + '-' + currency})
        .then((result) => {
            return result;
        })
        .catch(console.error);
    }
    
}

function getTickerInfo_ETH(currency){
    if(currency != 'ETH'){
        kc.getTicker({pair: 'ETH' + '-' + currency})
        .then((result) => {
            return result;
        })
        .catch(console.error);
    }
}




// Binance API
// const binance = require('node-binance-api');
// binance.options({
//     APIKEY: 'Xitz16nXSdRchH7F264GrfHNEDVKFhiWJFtB9ZEpXK1O5Kkd3XEL3OjuhrmmviYo',
//     APISECRET: 'xGz0IXzedftJPMCOku7ioURNgtduwY2wHymzn6h9ycq870uuOiDIDnoVxMHgdZMK'
// });

// binance.bookTickers(function(ticker){
//     console.log("bookTickers", ticker);
// });

// Poloniex API
// const Poloniex = require('poloniex-api-node');
// let poloniex = new Poloniex('LDPW9B47-5AVFAZD3-QPWLEH2V-3ZZFG8GS', '87a6a32990bdc38894b13c1bd6892b67d6d4102ff9db741cfc31bcdee587922ffa7a85d5a95581d8195e4045936d3926b25995801eb66453f0d53c727875b1ab', {});

//poloniex.returnChartData('DOGE_BTC', )

// poloniex.returnOrderBook('BTC_DOGE', 1000, function(err, data){

//     console.log(data);
// });


// poloniex.returnChartData('BTC_DOGE', 1800, '1515420000', '1515423600', function(err, data){
//     console.log(data);
// });

// poloniex.returnTicker(function(err, data){
//    console.log(data['BTC_DOGE']);
// });