module.exports = {
    twit:{
        consumer_key: 'Vykd0MFUSTdST40H6QDoOYzBv',
        consumer_secret: 'f18RIeBT9h5ftPyH20ln2im1g1iX6wwnQvTkUKEi0fHH7R3Ytp',
        access_token: '475465569-RTLCgLzmBo14QEYyDaxsXrt8miTBZfM10ocBFZjJ',
        access_token_secret: 'ppo32tPpUoL1OgOKBcLigSpE0TdSCYWNI5NV9udb7ACBZ'
    }
}